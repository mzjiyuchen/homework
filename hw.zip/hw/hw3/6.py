# 此题借助大模型
# 思路：本题可使用双指针法来解决。其核心思路是通过维护左右两个指针，分别从数组两端向中间移动，
# 利用已经遍历过的部分中最高柱子的高度信息，来计算当前位置能接住的雨水量。
# 初始化左右指针 left 和 right，分别指向数组的起始位置和末尾位置。
# 初始化 left_max 和 right_max 分别记录左边和右边遍历过的最高柱子高度，初始值为 0。
# 当 left 指针小于 right 指针时，进行如下操作：
# 比较 height[left] 和 height[right] 的大小：
# 若 height[left] <= height[right]，说明当前位置能接住的雨水量取决于左边的最高柱子高度。
# 若 height[left] > height[right]，说明当前位置能接住的雨水量取决于右边的最高柱子高度。
# 重复上述步骤，直到 left 指针和 right 指针相遇，将每一步计算得到的雨水量累加起来，就是最终能接住的雨水量。

def trap(height):
    if not height:
        return 0
    left, right = 0, len(height) - 1
    left_max, right_max = 0, 0
    res = 0
    while left < right:
        if height[left] <= height[right]:
            left_max = max(left_max, height[left])
            res += left_max - height[left]
            left += 1
        else:
            right_max = max(right_max, height[right])
            res += right_max - height[right]
            right -= 1
    return res

# 测试
height = [0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1]
print(trap(height))

# 时间复杂度O（n）