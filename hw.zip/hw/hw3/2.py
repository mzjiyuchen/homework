# 此题借助大模型
# 思路：



import graphviz

# 定义二叉树节点类
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

# 构建二叉搜索树函数
def build_bst(nums):
    root = None
    for num in nums:
        root = insert(root, num)
    return root

# 插入节点函数
def insert(root, val):
    if root is None:
        return TreeNode(val)
    if val < root.val:
        root.left = insert(root.left, val)
    else:
        root.right = insert(root.right, val)
    return root

# 删除节点函数
def delete(root, val):
    if root is None:
        return root
    if val < root.val:
        root.left = delete(root.left, val)
    elif val > root.val:
        root.right = delete(root.right, val)
    else:
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left
        temp = min_value_node(root.right)
        root.val = temp.val
        root.right = delete(root.right, temp.val)
    return root

# 找到节点右子树的最小节点
def min_value_node(node):
    current = node
    while current.left:
        current = current.left
    return current

# 绘制二叉树函数
def draw_bst(root, dot=None):
    if dot is None:
        dot = graphviz.Digraph(comment='Binary Search Tree')
    if root:
        dot.node(str(id(root)), str(root.val))
        if root.left:
            dot.edge(str(id(root)), str(id(root.left)))
            draw_bst(root.left, dot)
        if root.right:
            dot.edge(str(id(root)), str(id(root.right)))
            draw_bst(root.right, dot)
    return dot

nums = [48, 33, 49, 47, 42, 46, 32]
root = build_bst(nums)
# 绘制构建后的二叉搜索树
dot = draw_bst(root)
dot.render('original_bst', view=True)

root = delete(root, 33)
# 绘制删除33后的二叉搜索树
dot = draw_bst(root)
dot.render('modified_bst', view=True)