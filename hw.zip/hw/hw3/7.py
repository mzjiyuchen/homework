# 此题借助大模型
# 思路：
# 本题可类比为经典的背包问题，背包容量是总预算（这里假设预算足够容纳这些股票投资金额组合 ），物品的重量是股票投资金额，价值是预期收益。
# 采用贪心算法求解，核心思路是按照单位投资金额的预期收益率（预期收益率 / 投资金额）对股票进行排序，优先选择单位投资金额预期收益率高的股票，直到达到预算上限 。
# 计算单位投资金额预期收益率：分别计算每只股票单位投资金额的预期收益率
# 按单位投资金额预期收益率从高到低排序：排序后为 股票 C > 股票 B > 股票 A。
# 选择股票：按照排序依次选择股票，直到投资金额达到预算上限（本题无预算限制，可全部选择 ）。所以最优投资方案是选择股票 C、股票 B、股票 A 。

# 定义股票信息，每个元素为(投资金额, 预期收益率)
stocks = [(5000, 0.1), (3000, 0.08), (2000, 0.12)]

# 计算单位投资金额预期收益率并添加到股票信息中
for i in range(len(stocks)):
    investment, rate = stocks[i]
    stocks[i] = (investment, rate, rate / investment)

# 按照单位投资金额预期收益率从高到低排序
stocks.sort(key=lambda x: x[2], reverse=True)

# 输出最优投资方案
optimal_investment = []
total_investment = 0
for stock in stocks:
    investment, rate, _ = stock
    total_investment += investment
    optimal_investment.append((investment, rate))
print("最优投资方案：")
for investment, rate in optimal_investment:
    print(f"投资金额: {investment}美元, 预期收益率: {rate * 100}%")

 #  整体代码平均时间复杂度为 O(nlogn)