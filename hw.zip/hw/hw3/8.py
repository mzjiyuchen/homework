# 此题借助大模型
# 思路：
# 二叉搜索树（BST）的中序遍历结果是一个递增序列。由于恰好有两个节点的值被交换，那么在中序遍历过程中，会发现有两个位置不满足递增关系。
# 进行中序遍历二叉搜索树，记录遍历过程中的节点。
# 遍历记录的节点序列，找到两个不满足递增关系的节点。第一个不满足的节点是较大值（被交换到了前面），第二个不满足的节点（如果存在）是较小值（被交换到了后面） 。
# 若只找到一个不满足的节点，说明是相邻节点交换，该节点就是较大值，其下一个节点是较小值。
# 交换找到的这两个节点的值，即可恢复二叉搜索树。

# 定义二叉树节点类
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def recoverTree(root):
    nodes = []

    # 中序遍历
    def inorderTraversal(node):
        if node:
            inorderTraversal(node.left)
            nodes.append(node)
            inorderTraversal(node.right)

    inorderTraversal(root)
    first = None
    second = None
    for i in range(len(nodes) - 1):
        if nodes[i].val > nodes[i + 1].val:
            second = nodes[i + 1]
            if not first:
                first = nodes[i]
            else:
                break
    if first and second:
        first.val, second.val = second.val, first.val
    return root

# 示例构建二叉树
root = TreeNode(1)
root.right = TreeNode(3)
root.right.left = TreeNode(2)
recovered_root = recoverTree(root)


# 时间复杂度为O（n）