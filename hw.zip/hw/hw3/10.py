# 此题借助大模型
# 思路：
# 判断二叉树是否轴对称，可通过递归比较二叉树的左子树和右子树。核心在于对比左子树的左分支与右子树的右分支，以及左子树的右分支与右子树的左分支 。
# 定义一个递归函数，接收两棵子树（左子树和右子树）作为参数。
# 若两棵子树都为空，说明当前子树部分对称，返回 True。
# 若其中一棵子树为空，另一棵不为空，说明不对称，返回 False。
# 若两棵子树都不为空，但根节点值不相等，返回 False。
# 递归调用该函数，分别比较左子树的左分支与右子树的右分支，以及左子树的右分支与右子树的左分支，并将两个比较结果进行逻辑与运算，返回最终结果。


# 定义二叉树节点类
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def isSymmetric(root):
    def helper(left, right):
        if left is None and right is None:
            return True
        if left is None or right is None:
            return False
        if left.val != right.val:
            return False
        return helper(left.left, right.right) and helper(left.right, right.left)
    if root is None:
        return True
    return helper(root.left, root.right)

# 示例构建二叉树
root = TreeNode(1)
root.left = TreeNode(2)
root.right = TreeNode(2)
root.left.left = TreeNode(3)
root.left.right = TreeNode(4)
root.right.left = TreeNode(4)
root.right.right = TreeNode(3)
print(isSymmetric(root))

# 时间复杂度为O（n）