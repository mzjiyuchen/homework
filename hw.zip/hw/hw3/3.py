# 此题借助大模型
# 思路：
# 使用贪心算法解决该问题，核心思路是按照课程的开始时间对课程进行排序，然后遍历课程，为每门课程分配最早结束且能容纳它（即课程开始时间大于等于教室当前结束时间）的教室。
# 如果没有符合条件的教室，则新增一间教室。
# 将课程按照开始时间进行排序。
# 初始化一个列表来存储教室信息，每个教室记录其当前的结束时间。
# 遍历排序后的课程列表：
# 对于每门课程，检查已有的教室中是否存在结束时间早于或等于该课程开始时间的教室。
# 如果存在，将该课程安排到这个教室，并更新教室的结束时间为该课程的结束时间。
# 如果不存在，新增一间教室，并将该课程安排到新教室，同时记录新教室的结束时间为该课程的结束时间。
# 最终，教室列表的长度就是所需的最少教室数量，教室列表中的信息对应每个教室安排的课程。

def assign_classrooms(courses):
    # 按照课程开始时间排序
    courses.sort()
    classrooms = []
    for course in courses:
        assigned = False
        for i, classroom in enumerate(classrooms):
            if course[0] >= classroom[-1][1]:
                classroom.append(course)
                assigned = True
                break
        if not assigned:
            classrooms.append([course])
    return classrooms

courses = [(9 * 60, 12 * 60 + 30), (11 * 60, 14 * 60), (13 * 60, 14 * 60 + 30), (9 * 60, 10 * 60 + 30),
           (13 * 60, 14 * 60 + 30), (14 * 60, 16 * 60 + 30), (15 * 60, 16 * 60 + 30), (15 * 60, 16 * 60 + 30),
           (9 * 60, 10 * 60 + 30)]
result = assign_classrooms(courses)
num_classrooms = len(result)
print(f"最少需要{num_classrooms}间教室")
for i, classroom in enumerate(result):
    print(f"教室{i + 1}安排的课程: {[(start // 60, end // 60) for start, end in classroom]}")