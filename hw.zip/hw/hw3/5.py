def max(weights, values, n):
    n = len(weights)
    dp = [[0] * (n + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        for j in range(1, n + 1):
            dp[i][j] = dp[i - 1][j]
            if j >= weights[i - 1]:
                dp[i][j] = max(dp[i][j], dp[i - 1][j - weights[i - 1]] + values[i - 1])
    return dp[n][n]

weights = [5, 4, 6, 3]
values = [10, 40, 30, 50]
n = 9
print(max(weights, values, n))

# 时间复杂都为O（nw）