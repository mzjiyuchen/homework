# 此题借助大模型
# 思路：
# 采用深度优先搜索（DFS）的策略来遍历二叉树。在遍历过程中，从根节点开始，记录从根节点到当前节点路径所代表的数字。当到达叶节点时，将该路径代表的数字累加到结果中。
# 定义一个递归函数，参数包括当前节点、当前路径代表的数字（初始为 0）和结果变量（初始为 0）。
# 在递归函数中，更新当前路径代表的数字，即将其乘以 10 并加上当前节点的值。
# 判断当前节点是否为叶节点（即没有左子节点和右子节点），如果是，将当前路径代表的数字累加到结果变量中。
# 递归调用左子树和右子树，继续上述过程。
# 最终返回结果变量，即为从根节点到叶节点生成的所有数字之和。

# 定义二叉树节点类
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def sumNumbers(root):
    def dfs(node, num, total):
        if not node:
            return total
        num = num * 10 + node.val
        if not node.left and not node.right:
            total += num
        total = dfs(node.left, num, total)
        total = dfs(node.right, num, total)
        return total
    return dfs(root, 0, 0)

# 示例构建二叉树
root = TreeNode(4)
root.left = TreeNode(9)
root.right = TreeNode(0)
root.left.left = TreeNode(5)
root.left.right = TreeNode(1)
result = sumNumbers(root)
print(result)

# 时间复杂度为O（n）