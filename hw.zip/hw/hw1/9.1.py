# 此题借助大模型
# 伪代码
Modified-Quicksort(A, p, r):
    if p < r:
        # 使用黑盒选择算法找到中位数下标
        median_idx = BB(A, p, r, (r - p + 1) # 2)
        # 将中位数交换到末尾作为枢轴
        swap(A[median_idx], A[r])
        # 划分
        q = Partition(A, p, r)
        # 递归排序左右两部分
        Modified-Quicksort(A, p, q - 1)
        Modified-Quicksort(A, q + 1, r)

#  时间复杂度 O（nlogn）