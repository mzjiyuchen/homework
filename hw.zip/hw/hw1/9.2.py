# 此题借助大模型
# 伪代码
Find-Top-k(A, k):
    # 找到第k小的元素
    kth_idx = BB(A, 1, n, k)
    x = A[kth_idx]
    # 收集所有≤x的元素
    result = []
    for num in A:
        if num ≤ x:
            result.append(num)
    # 返回前k个（可能有重复值需处理）
    return sorted(result)[:k]

# 时间复杂度 O（n/logn）