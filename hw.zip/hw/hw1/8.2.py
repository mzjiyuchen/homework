# 此题借助大模型
import heapq

def find_k_smallest_heap(arr, k):
    if k == 0:
        return []

    max_heap = [-x for x in arr[:k]]
    heapq.heapify(max_heap)

    for num in arr[k:]:
        if -max_heap[0] > num:
            heapq.heapreplace(max_heap, -num)

    result = [-x for x in max_heap]
    return sorted(result)


arr = [5, 4, 3, 2, 6, 1, 88, 33, 22, 107]
k = 3
print(find_k_smallest_heap(arr, k))

#  时间复杂度 O（nlogn）