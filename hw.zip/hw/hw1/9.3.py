# 此题借助大模型
# 伪代码
K-Partition(A, p, r, k):
    if k == 1:
        return
    # 找到第 (r - p + 1)/k 小的元素作为划分点
    m = (r - p + 1) # k
    pivot_idx = BB(A, p, r, m)
    pivot = A[pivot_idx]
    # 划分数组
    Partition(A, p, r, pivot)
    # 递归处理左半部分和剩余划分
    K-Partition(A, p, pivot_idx - 1, k # 2)
    K-Partition(A, pivot_idx + 1, r, k - k # 2)

#  时间复杂度 O（nlogk）