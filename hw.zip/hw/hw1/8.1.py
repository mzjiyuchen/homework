def sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                temp = arr[j]
                arr[j] = arr[j + 1]
                arr[j + 1] = temp
    return arr

arr = [5, 4, 3, 2, 6, 1, 88, 33, 22, 107]
a = 3
arr_sort = sort(arr)
for i in range(a):
    print(arr[i])

#  时间复杂度O（n）

