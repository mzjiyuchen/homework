def count(nums):
    a = {}
    for i in nums:
        if i in a:
            a[i] += 1
        else:
            a[i] = 1

        if a[i] > len(nums) // 2:
            return i

num1 = [3, 2, 3]
num2 = [2, 2, 1, 1, 1, 2, 2]
print(count(num1))
print(count(num2))