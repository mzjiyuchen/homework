def max(p):
    min_price = p[0]
    max_profit = 0
    buy_day = 0
    sell_day = 0
    update = 0

    for i in range(1, len(p)):
        price = p[i]
        profit = price - min_price

        if profit > max_profit:
            max_profit = profit
            sell_day = i
            buy_day = update

        if price < min_price:
            min_price = price
            update = i

    return max_profit, buy_day, sell_day

profits = [3,2,1,-7,5,2,-1,3,-1]
profit, buy, sell = max(profits)
print(f"最大利润: {profit}, 买入日期: {buy+1}, 卖出日期: {sell+1}")