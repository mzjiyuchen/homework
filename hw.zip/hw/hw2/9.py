# 此题借助大模型
# 思路：定义三维数组 dp[i][j][k] ，其中i表示考虑前i个物品，j表示第一个背包剩余容量，k 表示第二个背包剩余容量，dp[i][j][k] 表示在这种状态下能获得的最大价值。
# 对于第 i 个元素 a[i]（集合 S 中索引为 i 的元素），有两种情况：
# 不选择第 i 个元素：此时 dp[i][j] 的值取决于 dp[i - 1][j]，即前 i - 1 个元素能否组成和为 j 的子集。
# 选择第 i 个元素：前提是 j >= a[i]，此时 dp[i][j] 的值取决于 dp[i - 1][j - a[i]]，即前 i - 1 个元素能否组成和为 j - a[i] 的子集。
# 综合起来，状态转移方程为：dp[i][j] = dp[i - 1][j] or (dp[i - 1][j - a[i]] if j >= a[i] else False)


def max_value(V, W, c):
    n = len(V)
    dp = [[[0 for _ in range(c + 1)] for _ in range(c + 1)] for _ in range(n + 1)]
    for i in range(1, n + 1):
        for j in range(c + 1):
            for k in range(c + 1):
                dp[i][j][k] = dp[i - 1][j][k]
                if j >= W[i - 1]:
                    dp[i][j][k] = max(dp[i][j][k], dp[i - 1][j - W[i - 1]][k] + V[i - 1])
                if k >= W[i - 1]:
                    dp[i][j][k] = max(dp[i][j][k], dp[i - 1][j][k - W[i - 1]] + V[i - 1])
    return dp[n][c][c]

V = [1, 3, 2, 5, 8, 7]
W = [1, 3, 2, 5, 8, 7]
c = 7
print("最大价值=", max_value(V, W, c))