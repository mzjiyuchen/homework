# 此题借助大模型
# 思路：从左到右遍历房屋坐标数组。对于每个房屋，优先考虑在其右侧 4 公里范围内设置基站，这样能覆盖尽可能多后续的房屋。
# 具体来说，当遍历到一个房屋坐标时，先尝试在该房屋右侧 4 公里处（即坐标值加上 4 ）设置基站，
# 然后看这个基站能覆盖到数组中的哪些房屋，直到遇到超出覆盖范围的房屋，再对下一个未覆盖房屋重复此过程，直到所有房屋都被覆盖。


def min_base_stations(houses):
    n = len(houses)
    if n == 0:
        return 0, []
    base_stations = []
    i = 0
    while i < n:
        # 以当前房屋为基准，在其右侧4公里处尝试设置基站
        coverage_end = houses[i] + 4
        # 移动指针，找到该基站覆盖范围内最右侧的房屋
        while i < n and houses[i] <= coverage_end:
            i += 1
        # 将基站设置在覆盖范围内最右侧房屋的位置
        base_stations.append(houses[i - 1])
        # 更新覆盖范围，以新设置的基站为基准
        coverage_end = houses[i - 1] + 4
        # 移动指针，跳过已覆盖的房屋
        while i < n and houses[i] <= coverage_end:
            i += 1
    return len(base_stations), base_stations

houses = [1, 5, 12, 33, 34, 35]
num_stations, stations = min_base_stations(houses)
print(f"基站数目为{num_stations}，基站位置为{stations}")