# 此题借助大模型
# 思路： 使用栈来模拟星球的碰撞过程。从左到右遍历数组，对于每个星球：
# 若栈为空，或者当前星球向右运动（正数），直接将其压入栈中。
# 若栈不为空且当前星球向左运动（负数），则与栈顶元素进行碰撞判断：
# 若栈顶星球质量大于当前星球（abs(栈顶元素) > abs(当前元素)），当前星球消失，不做其他操作。
# 若栈顶星球质量小于当前星球（abs(栈顶元素) < abs(当前元素)），弹出栈顶元素，继续与新的栈顶元素比较（如果栈非空），直到栈空或者栈顶星球质量大于等于当前星球。
# 若栈顶星球质量等于当前星球（abs(栈顶元素) == abs(当前元素)），且栈顶星球向右运动，弹出栈顶元素，当前星球消失；若栈顶星球向左运动，当前星球压入栈中。

def asteroid_collision(asteroids):
    stack = []
    for asteroid in asteroids:
        if not stack or asteroid > 0:
            stack.append(asteroid)
        else:
            while stack:
                top = stack[-1]
                if top < 0:
                    stack.append(asteroid)
                    break
                elif abs(top) > abs(asteroid):
                    break
                elif abs(top) < abs(asteroid):
                    stack.pop()
                    continue
                else:
                    stack.pop()
                    break
    return stack

A = [23, -8, 9, -3, -7, 9, -23, 22]
print(asteroid_collision(A))

# 时间复杂度O（n）