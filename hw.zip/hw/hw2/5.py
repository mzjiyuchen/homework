# 此题借助大模型
# 思路：首先要构建二叉搜索树，实现删除节点和中序遍历的功能
# 构建二叉搜索树，要定义TreeNode 类表示二叉树节点，要包含插入操作
# 删除节点：先实现 find_parent 函数来查找目标节点的父节点，通过比较目标值和当前节点值，在树中向下遍历找到父节点。
# 找到目标节点及其父节点后，分情况处理：
# 1.若目标节点无左子节点或无右子节点（即只有一个子节点或无子节点），直接用其子节点（若有）替代目标节点在其父节点中的位置。
# 2.若目标节点有两个子节点，找到其右子树中的最小节点（即后继节点），将后继节点的值赋给目标节点，然后删除后继节点（后继节点最多只有一个右子节点，按上述只有一个子节点或无子节点的情况处理）。
# 中序遍历 ：实现 inorder_traversal 函数，采用递归方式进行中序遍历：

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

# 插入节点到二叉搜索树
def insert(root, val):
    if root is None:
        return TreeNode(val)
    if val < root.val:
        root.left = insert(root.left, val)
    else:
        root.right = insert(root.right, val)
    return root

# 构建二叉搜索树
def build_bst(nums):
    root = None
    for num in nums:
        root = insert(root, num)
    return root

# 查找节点的父节点
def find_parent(root, val):
    parent = None
    while root:
        if val < root.val:
            parent = root
            root = root.left
        elif val > root.val:
            parent = root
            root = root.right
        else:
            return parent
    return None

# 删除节点
def delete(root, val):
    parent = find_parent(root, val)
    node = root
    while node and node.val != val:
        if val < node.val:
            node = node.left
        else:
            node = node.right
    if node is None:
        return root
    # 情况1：节点没有子节点或只有一个子节点
    if node.left is None or node.right is None:
        child = node.left if node.left else node.right
        if parent is None:  # 要删除的是根节点
            root = child
        elif parent.left == node:
            parent.left = child
        else:
            parent.right = child
    # 情况2：节点有两个子节点
    else:
        successor_parent = node
        successor = node.right
        while successor.left:
            successor_parent = successor
            successor = successor.left
        node.val = successor.val
        if successor_parent.left == successor:
            successor_parent.left = successor.right
        else:
            successor_parent.right = successor.right
    return root

# 中序遍历
def inorder_traversal(root):
    result = []
    def inorder(root):
        if root:
            inorder(root.left)
            result.append(root.val)
            inorder(root.right)
    inorder(root)
    return result

nums = [9, -3, -10, 0, 9, 7, 33]
root = build_bst(nums)
root = delete(root, 0)
result = inorder_traversal(root)
print(result)

#  整体代码平均时间复杂度为 O(nlogn) ，最差时间复杂度为 O(n2)
