class NodeList:
    def __init__(self, val=None, right=None):
        self.val = val
        self.right = right

def delete(arr):
    list = NodeList(arr[0])
    a = list
    for i in arr[1:len(arr)]:
        a.right = NodeList(i)
        a = a.right

    b = list
    while b and b.right:
        if b.val == b.right.val:
            b.right = b.right.right
        else:
            b = b.right

    result = []
    c = list
    while c:
        result.append(c.val)
        c = c.right
    return result

list = [1, 1, 2, 3, 3]
print(delete(list))

# 时间复杂度O（n）