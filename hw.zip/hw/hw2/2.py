def find(nums, target):
    dict = {}
    for i, num in enumerate(nums):
        a = target - num
        if a in dict:
            return [dict[a], i]
        dict[num] = i

nums = [2, 7, 11, 15]
target = 9
print(find(nums, target))

# 时间复杂度O（n）