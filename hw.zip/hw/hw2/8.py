# 此题借助大模型
# 思路：本题可以使用动态规划（Dynamic Programming，DP）来解决。动态规划的核心是利用问题的最优子结构性质，通过保存子问题的解来避免重复计算。
# 对于第 i 个元素 a[i]（集合 S 中索引为 i 的元素），有两种情况：
# 不选择第 i 个元素：此时 dp[i][j] 的值取决于 dp[i - 1][j]，即前 i - 1 个元素能否组成和为 j 的子集。
# 选择第 i 个元素：前提是 j >= a[i]，此时 dp[i][j] 的值取决于 dp[i - 1][j - a[i]]，即前 i - 1 个元素能否组成和为 j - a[i] 的子集。
# 综合起来，状态转移方程为：dp[i][j] = dp[i - 1][j] or (dp[i - 1][j - a[i]] if j >= a[i] else False)


def subset_sum(S, W):
    n = len(S)
    # 初始化dp数组
    dp = [[False] * (W + 1) for _ in range(n + 1)]
    dp[0][0] = True
    for i in range(1, n + 1):
        for j in range(W + 1):
            dp[i][j] = dp[i - 1][j]
            if j >= S[i - 1]:
                dp[i][j] = dp[i][j] or dp[i - 1][j - S[i - 1]]
    return dp[n][W]

S = [1, 4, 7, 3, 5]
W = 11
print(subset_sum(S, W))