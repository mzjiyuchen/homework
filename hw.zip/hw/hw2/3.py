# 此题借助大模型
# 思路：
# 1.初始化两个栈：operands（操作数）和 operators（运算符）。
# 2.遍历表达式：遇到数字，解析完整的数字并压入 operands； 遇到运算符，比较当前运算符与 operators 栈顶的优先级：若栈顶优先级更高或相等，则弹出栈顶运算符和两个操作数进行计算，结果压回 operands，重复此过程； 否则，当前运算符压入 operators。
# 3.处理剩余运算符：遍历结束后，依次弹出 operators 中的运算符进行计算。
# 4.返回结果：operands 栈顶即为最终结果。

def evaluate_expression(expression):
    def compute(op, a, b):
        if op == '+': return a + b
        if op == '-': return a - b
        if op == '*': return a * b
        if op == '/': return a // b
        return 0

    operands = []
    operators = []
    i = 0
    n = len(expression)
    precedence = {'+': 1, '-': 1, '*': 2, '/': 2}

    while i < n:
        if expression[i] == ' ':
            i += 1
            continue
        if expression[i].isdigit():
            num = 0
            while i < n and expression[i].isdigit():
                num = num * 10 + int(expression[i])
                i += 1
            operands.append(num)
        else:
            op = expression[i]
            while (operators and precedence[operators[-1]] >= precedence[op]):
                b = operands.pop()
                a = operands.pop()
                operands.append(compute(operators.pop(), a, b))
            operators.append(op)
            i += 1

    while operators:
        b = operands.pop()
        a = operands.pop()
        operands.append(compute(operators.pop(), a, b))

    return operands[0]

# 测试示例
print(evaluate_expression("3 + 5 * 8 - 6"))
print(evaluate_expression("34 + 13 * 9 + 44 - 12 / 3"))

# 时间复杂度 O（n）